# Planificación del proyecto

| Semana | Actividad | Responsable |
|---|---|---|
| 1 | Revisión del proyecto anterior y requerimientos | Equipo |
| 2 | Validación de necesidades y arquitectura | Equipo |
| 3 | Diseño de interfaz y navegación | Front-End |
| 4 | Implementación API y modelos | Back-End |
| 5 | Integración y pruebas | Equipo |
| 6 | Ajustes, documentación y entrega | Equipo |

## Próximas etapas
- Completar autenticación de usuarios.
- Conectar todas las pantallas con la API.
- Agregar validaciones.
- Realizar pruebas de accesibilidad y diseño responsivo.
- Incorporar datos reales autorizados por el socio comunitario.
