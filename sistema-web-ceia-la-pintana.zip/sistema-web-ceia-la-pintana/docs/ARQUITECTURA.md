# Arquitectura Full Stack

## Front-End
React se utiliza para construir una interfaz modular, responsiva e interactiva.

## Back-End
Django REST Framework expone endpoints REST para gestionar información de estudiantes e inventario.

## Comunicación
El Front-End puede consumir la API mediante solicitudes HTTP en formato JSON.

## Accesibilidad
La propuesta considera:
- textos legibles;
- estructura clara;
- navegación simple;
- diseño adaptable;
- estados visuales para alertas.
