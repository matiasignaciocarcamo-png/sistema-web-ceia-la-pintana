from django.db import models

class Estudiante(models.Model):
    nombre = models.CharField(max_length=120)
    curso = models.CharField(max_length=80)
    asistencia = models.DecimalField(max_digits=5, decimal_places=2, default=100)

    @property
    def alerta_asistencia(self):
        return self.asistencia < 85

    def __str__(self):
        return self.nombre

class Inventario(models.Model):
    articulo = models.CharField(max_length=120)
    cantidad = models.PositiveIntegerField(default=0)
    estado = models.CharField(max_length=80, default='Disponible')

    def __str__(self):
        return self.articulo
