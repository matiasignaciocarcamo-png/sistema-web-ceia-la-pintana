from rest_framework.routers import DefaultRouter
from .views import EstudianteViewSet, InventarioViewSet

router = DefaultRouter()
router.register('estudiantes', EstudianteViewSet)
router.register('inventario', InventarioViewSet)

urlpatterns = router.urls
