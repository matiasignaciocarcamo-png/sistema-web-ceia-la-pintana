from django.contrib import admin
from .models import Estudiante, Inventario

admin.site.register(Estudiante)
admin.site.register(Inventario)
