from rest_framework import serializers
from .models import Estudiante, Inventario

class EstudianteSerializer(serializers.ModelSerializer):
    alerta_asistencia = serializers.ReadOnlyField()
    class Meta:
        model = Estudiante
        fields = '__all__'

class InventarioSerializer(serializers.ModelSerializer):
    class Meta:
        model = Inventario
        fields = '__all__'
