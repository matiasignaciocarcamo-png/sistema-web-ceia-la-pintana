import React, { useState } from 'react';
import Dashboard from './pages/Dashboard';
import Estudiantes from './pages/Estudiantes';
import Asistencia from './pages/Asistencia';
import Inventario from './pages/Inventario';
import Agenda from './pages/Agenda';

const pages = {
  dashboard: <Dashboard />,
  estudiantes: <Estudiantes />,
  asistencia: <Asistencia />,
  inventario: <Inventario />,
  agenda: <Agenda />,
};

export default function App() {
  const [page, setPage] = useState('dashboard');

  return (
    <div className="container-fluid">
      <div className="row">
        <aside className="col-md-3 col-lg-2 p-3 sidebar">
          <h4 className="mb-4">CEIA La Pintana</h4>
          <button className="btn btn-light" onClick={() => setPage('dashboard')}>Inicio</button>
          <button className="btn btn-outline-light" onClick={() => setPage('estudiantes')}>Estudiantes</button>
          <button className="btn btn-outline-light" onClick={() => setPage('asistencia')}>Asistencia</button>
          <button className="btn btn-outline-light" onClick={() => setPage('inventario')}>Inventario</button>
          <button className="btn btn-outline-light" onClick={() => setPage('agenda')}>Agenda</button>
        </aside>
        <main className="col-md-9 col-lg-10 p-4">
          {pages[page]}
        </main>
      </div>
    </div>
  );
}
