import React from 'react';

export default function Dashboard() {
  return (
    <>
      <h2>Panel principal</h2>
      <p className="text-muted">Resumen general de la gestión interna.</p>
      <div className="row g-3">
        <div className="col-md-4"><div className="card card-stat p-3"><h5>Estudiantes</h5><h2>128</h2></div></div>
        <div className="col-md-4"><div className="card card-stat p-3"><h5>Asistencia promedio</h5><h2>88%</h2></div></div>
        <div className="col-md-4"><div className="card card-stat p-3"><h5>Alertas</h5><h2>7</h2><small>Asistencia menor a 85%</small></div></div>
      </div>
    </>
  );
}
