import React from 'react';

export default function Inventario() {
  return (
    <>
      <h2>Inventario</h2>
      <table className="table table-bordered bg-white">
        <thead><tr><th>Artículo</th><th>Cantidad</th><th>Estado</th></tr></thead>
        <tbody>
          <tr><td>Notebook</td><td>12</td><td>Disponible</td></tr>
          <tr><td>Proyector</td><td>4</td><td>Disponible</td></tr>
          <tr><td>Impresora</td><td>2</td><td>Mantención</td></tr>
        </tbody>
      </table>
    </>
  );
}
