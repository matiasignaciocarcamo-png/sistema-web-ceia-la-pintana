import React from 'react';

export default function Agenda() {
  return (
    <>
      <h2>Agenda</h2>
      <div className="list-group">
        <div className="list-group-item"><strong>Lunes:</strong> Reunión de coordinación.</div>
        <div className="list-group-item"><strong>Miércoles:</strong> Revisión de asistencia.</div>
        <div className="list-group-item"><strong>Viernes:</strong> Actualización de inventario.</div>
      </div>
    </>
  );
}
