import React from 'react';

const datos = [
  {nombre: 'Ana Pérez', curso: '1° Nivel', asistencia: 92},
  {nombre: 'Luis Soto', curso: '2° Nivel', asistencia: 81},
  {nombre: 'María Díaz', curso: '1° Nivel', asistencia: 87},
];

export default function Estudiantes() {
  return (
    <>
      <h2>Estudiantes</h2>
      <div className="table-wrap">
        <table className="table table-striped bg-white">
          <thead><tr><th>Nombre</th><th>Curso</th><th>Asistencia</th><th>Estado</th></tr></thead>
          <tbody>
            {datos.map((e, i) => (
              <tr key={i}>
                <td>{e.nombre}</td><td>{e.curso}</td><td>{e.asistencia}%</td>
                <td>{e.asistencia < 85 ? <span className="badge text-bg-danger">Alerta</span> : <span className="badge text-bg-success">Normal</span>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
