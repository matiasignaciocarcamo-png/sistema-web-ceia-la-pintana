import React, { useState } from 'react';

export default function Asistencia() {
  const [porcentaje, setPorcentaje] = useState(84);
  return (
    <>
      <h2>Asistencia</h2>
      <div className="card p-4">
        <label className="form-label">Porcentaje de asistencia</label>
        <input className="form-control mb-3" type="number" value={porcentaje} onChange={e => setPorcentaje(Number(e.target.value))}/>
        {porcentaje < 85
          ? <div className="alert alert-danger">Alerta: asistencia inferior al 85%.</div>
          : <div className="alert alert-success">Asistencia dentro del rango esperado.</div>}
      </div>
    </>
  );
}
