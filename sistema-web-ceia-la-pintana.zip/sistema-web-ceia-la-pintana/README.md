# Sistema Web de Gestión Interna CEIA La Pintana

Proyecto Full Stack desarrollado como propuesta para la evaluación **EPE 1**.

## Objetivo
Diseñar una aplicación web que permita organizar información del establecimiento y representar las principales funciones de gestión interna.

## Módulos considerados
- Estudiantes
- Cursos
- Asistencia
- Inventario
- Agenda
- Usuarios
- Alertas de asistencia bajo 85%

## Tecnologías
### Front-End
- React
- Vite
- Bootstrap
- JavaScript

### Back-End
- Python
- Django
- Django REST Framework
- SQLite para desarrollo

## Estructura
- `frontend/`: interfaz web.
- `backend/`: API REST.
- `docs/`: documentación y planificación.

## Cómo ejecutar

### Back-End
```bash
cd backend
python -m venv venv
# Windows:
venv\Scripts\activate
# macOS/Linux:
# source venv/bin/activate

pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
```

### Front-End
```bash
cd frontend
npm install
npm run dev
```

El Front-End queda disponible normalmente en `http://localhost:5173` y el Back-End en `http://127.0.0.1:8000`.

## Estado
Prototipo académico funcional inicial. Puede ampliarse durante las siguientes etapas del proyecto.

## Integrantes
- Integrante 1: ____________________
- Integrante 2: ____________________
- Integrante 3: ____________________

## Institución
Instituto Profesional de Chile (IPCHILE)
